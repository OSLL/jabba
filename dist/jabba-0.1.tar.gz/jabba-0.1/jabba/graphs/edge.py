

class Edge(object):

    __splots__ = ['to', 'settings']

    def __init__(self, to, settings):
        self.to = to
        self.settings = settings
