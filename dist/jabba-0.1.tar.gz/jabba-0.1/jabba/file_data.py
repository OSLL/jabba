
import collections

FileData = collections.namedtuple('FileData', ['path', 'yaml'])

